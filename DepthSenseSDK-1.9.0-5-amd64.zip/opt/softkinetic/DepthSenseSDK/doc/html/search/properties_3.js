var searchData=
[
  ['datatype',['dataType',['../classDepthSense_1_1Depth_1_1IMUData.html#a8d8266074c9926a6ea729fc1ac0c7c84',1,'DepthSense::Depth::IMUData']]],
  ['depthmap',['depthMap',['../classDepthSense_1_1Depth_1_1SampleData.html#a61422908f03bc68f012e995ab584bf2a',1,'DepthSense::Depth::SampleData']]],
  ['depthmap3planes',['depthMap3Planes',['../classDepthSense_1_1DepthNode.html#a7f2a7ad35fb9a62674bdc9d092573abb',1,'DepthSense::DepthNode']]],
  ['depthmapfloatingpoint',['depthMapFloatingPoint',['../classDepthSense_1_1Depth_1_1SampleData.html#a1cc8ca012743536c3bf3c000a98e9c91',1,'DepthSense::Depth::SampleData']]],
  ['depthmapfloatingpoint3planes',['depthMapFloatingPoint3Planes',['../classDepthSense_1_1DepthNode.html#a41e793571b36789765fd2d1b9f362166',1,'DepthSense::DepthNode']]],
  ['devices',['devices',['../classDepthSense_1_1Context.html#adbaea92f9c84bc01941c6746120d6117',1,'DepthSense::Context']]],
  ['droppedsamplecount',['droppedSampleCount',['../classDepthSense_1_1Audio_1_1SampleData.html#a28fa60e70a50f0cbd606e26ecbec95e2',1,'DepthSense::Audio::SampleData::droppedSampleCount()'],['../classDepthSense_1_1Color_1_1SampleData.html#aaf4d40d39c89c52d9fec5b3b8b85f000',1,'DepthSense::Color::SampleData::droppedSampleCount()'],['../classDepthSense_1_1Depth_1_1SampleData.html#a932444677f8467c944142f1e66b4e601',1,'DepthSense::Depth::SampleData::droppedSampleCount()']]]
];
