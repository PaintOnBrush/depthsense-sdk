var searchData=
[
  ['samplerate',['sampleRate',['../structDepthSense_1_1Audio_1_1Configuration.html#a0a3539517c9f6c64ab3459305a8fa90a',1,'DepthSense::Audio::Configuration::sampleRate()'],['../structDepthSense_1_1AudioNode_1_1Configuration.html#a69455d373ca47133ec334c821500d19d',1,'DepthSense::AudioNode::Configuration::sampleRate()']]],
  ['saturation',['saturation',['../structDepthSense_1_1Depth_1_1Configuration.html#a2bdeb758414bc2b2173e86d042c6e344',1,'DepthSense::Depth::Configuration::saturation()'],['../structDepthSense_1_1DepthNode_1_1Configuration.html#a3702296dabb807c2b2d8ed822d46fa11',1,'DepthSense::DepthNode::Configuration::saturation()']]],
  ['sourceip',['sourceIP',['../structDepthSense_1_1Context_1_1ClientConnectedData.html#a27353f1da89a48cdebb3232afe06e3e0',1,'DepthSense::Context::ClientConnectedData::sourceIP()'],['../structDepthSense_1_1Context_1_1ClientDisconnectedData.html#ae2a993cc5d1d3f5e082b334f3439d7fd',1,'DepthSense::Context::ClientDisconnectedData::sourceIP()']]],
  ['sourceport',['sourcePort',['../structDepthSense_1_1Context_1_1ClientConnectedData.html#af823425d3b22489c5479132a6858b492',1,'DepthSense::Context::ClientConnectedData::sourcePort()'],['../structDepthSense_1_1Context_1_1ClientDisconnectedData.html#abae4d61440b3468dcb3f447d56d82dd7',1,'DepthSense::Context::ClientDisconnectedData::sourcePort()']]],
  ['stereocameraparameters',['stereoCameraParameters',['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#ae20a845a532360ca419ba267a088c87f',1,'DepthSense::DepthNode::NewSampleReceivedData']]]
];
