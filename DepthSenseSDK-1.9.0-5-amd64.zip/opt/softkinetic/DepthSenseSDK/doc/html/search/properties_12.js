var searchData=
[
  ['values',['values',['../classDepthSense_1_1Depth_1_1IMUData.html#ae274848c0164a9031829de38a734875b',1,'DepthSense::Depth::IMUData']]],
  ['vertices',['vertices',['../classDepthSense_1_1Depth_1_1SampleData.html#aa0c887e99e4110668947ebfcc66a410d',1,'DepthSense::Depth::SampleData']]],
  ['verticesfloatingpoint',['verticesFloatingPoint',['../classDepthSense_1_1Depth_1_1SampleData.html#a737b222145705590910e03049e8a8845',1,'DepthSense::Depth::SampleData']]],
  ['vid',['VID',['../classDepthSense_1_1Node.html#a1b36748116a60fbb5d7d14f31c916bfa',1,'DepthSense::Node']]]
];
