var searchData=
[
  ['cameramode',['CameraMode',['../classDepthSense_1_1DepthNode.html#a5f3df535bdb02b58fb654a0c6dba8c9e',1,'DepthSense::DepthNode']]],
  ['cameraplane',['CameraPlane',['../namespaceDepthSense.html#a57c659d5e702016bb71c489d83c40a6c',1,'DepthSense']]],
  ['capabilities',['Capabilities',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1',1,'DepthSense::Device']]],
  ['compressiontype',['CompressionType',['../namespaceDepthSense.html#ac0e14943b53ce044cb535f2b94562391',1,'DepthSense']]],
  ['coordinatesystemtype',['CoordinateSystemType',['../namespaceDepthSense.html#af03d4223413374093437dd4d2712181b',1,'DepthSense']]]
];
