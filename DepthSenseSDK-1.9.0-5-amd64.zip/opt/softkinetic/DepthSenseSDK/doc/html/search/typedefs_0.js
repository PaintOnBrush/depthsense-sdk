var searchData=
[
  ['type',['Type',['../classDepthSense_1_1Property.html#ac1a7fcfa0b85c8c8c68ac84ad2601c9e',1,'DepthSense::Property::Type()'],['../classDepthSense_1_1Property_3_01std_1_1string_01_4.html#a97c769ec1ab0f171a4ae9453790286c2',1,'DepthSense::Property&lt; std::string &gt;::Type()']]]
];
