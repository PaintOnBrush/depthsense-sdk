var searchData=
[
  ['bitspersample',['bitsPerSample',['../structDepthSense_1_1Audio_1_1Configuration.html#a1a81955105547c13ec96b57fd8075a28',1,'DepthSense::Audio::Configuration::bitsPerSample()'],['../structDepthSense_1_1AudioNode_1_1Configuration.html#a273c78fd12ad3b29338474e3facee5a9',1,'DepthSense::AudioNode::Configuration::bitsPerSample()']]],
  ['brightness',['brightness',['../classDepthSense_1_1ColorNode.html#ab7d5cc5370627296eac78b3bcb8bf264',1,'DepthSense::ColorNode']]],
  ['brightnessisreadonly',['brightnessIsReadOnly',['../classDepthSense_1_1ColorNode.html#a2c066dab0b8207614aa546e13aaebf0f',1,'DepthSense::ColorNode']]],
  ['build',['build',['../structDepthSense_1_1Version.html#a7f1fe71975e0989aea9ce92b8e3e8006',1,'DepthSense::Version']]],
  ['buttoneventdata',['ButtonEventData',['../classDepthSense_1_1Depth_1_1ButtonEventData.html',1,'DepthSense::Depth']]],
  ['buttonid',['buttonID',['../classDepthSense_1_1Depth_1_1ButtonEventData.html#a123f4e231f6f0d145487b2a65d5d3ce9',1,'DepthSense::Depth::ButtonEventData']]],
  ['buttonpresseddata',['ButtonPressedData',['../structDepthSense_1_1DepthNode_1_1ButtonPressedData.html',1,'DepthSense::DepthNode']]],
  ['buttonpressedevent',['ButtonPressedEvent',['../classDepthSense_1_1DepthNode_1_1ButtonPressedEvent.html',1,'DepthSense::DepthNode']]],
  ['buttonpressedevent',['buttonPressedEvent',['../classDepthSense_1_1DepthNode.html#aadf5e6fe129a41a083f1cf198e1ef39b',1,'DepthSense::DepthNode']]],
  ['buttonreleaseddata',['ButtonReleasedData',['../structDepthSense_1_1DepthNode_1_1ButtonReleasedData.html',1,'DepthSense::DepthNode']]],
  ['buttonreleasedevent',['ButtonReleasedEvent',['../classDepthSense_1_1DepthNode_1_1ButtonReleasedEvent.html',1,'DepthSense::DepthNode']]],
  ['buttonreleasedevent',['buttonReleasedEvent',['../classDepthSense_1_1DepthNode.html#abcf6573855e3cb9e01873e7ace3eacdd',1,'DepthSense::DepthNode']]]
];
