var searchData=
[
  ['acceleration',['acceleration',['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#ac139eedcc23dd3e76b1ccd95eea277b4',1,'DepthSense::DepthNode::NewSampleReceivedData']]],
  ['appname',['appName',['../structDepthSense_1_1Context_1_1ClientConnectedData.html#a7c8da7dc3148034ac1016f2c60f98ee1',1,'DepthSense::Context::ClientConnectedData::appName()'],['../structDepthSense_1_1Context_1_1ClientDisconnectedData.html#a6b9d01ae9ad68c5a9b09c8d6c88ca951',1,'DepthSense::Context::ClientDisconnectedData::appName()']]],
  ['audiodata',['audioData',['../structDepthSense_1_1AudioNode_1_1NewSampleReceivedData.html#a76a4b79b5876faf3dca4023205ecdb80',1,'DepthSense::AudioNode::NewSampleReceivedData']]]
];
