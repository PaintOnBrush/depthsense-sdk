var searchData=
[
  ['name',['name',['../classDepthSense_1_1PropertyBase.html#a1ae899343e90cf389baaba6b52effbb4',1,'DepthSense::PropertyBase::name()'],['../classDepthSense_1_1Type.html#a2bdce11e757bd1e7cee67fcd0c8248a7',1,'DepthSense::Type::name()']]],
  ['newsamplereceived2event',['newSampleReceived2Event',['../classDepthSense_1_1AudioNode.html#a6589ae339f977980007334c2ffafb980',1,'DepthSense::AudioNode::newSampleReceived2Event()'],['../classDepthSense_1_1ColorNode.html#ad49732af670017754ceaaa1259fc2ab9',1,'DepthSense::ColorNode::newSampleReceived2Event()'],['../classDepthSense_1_1DepthNode.html#a3346288187ea36e2136c11475bdfe4f3',1,'DepthSense::DepthNode::newSampleReceived2Event()']]],
  ['newsamplereceivedevent',['newSampleReceivedEvent',['../classDepthSense_1_1AudioNode.html#aac278155a360fb2a0439472f121e235c',1,'DepthSense::AudioNode::newSampleReceivedEvent()'],['../classDepthSense_1_1ColorNode.html#add6880f6600da3588bafaab7601b3875',1,'DepthSense::ColorNode::newSampleReceivedEvent()'],['../classDepthSense_1_1DepthNode.html#aac9b82b8c3612a4e8430edffe5ac228b',1,'DepthSense::DepthNode::newSampleReceivedEvent()']]],
  ['nodeaddedevent',['nodeAddedEvent',['../classDepthSense_1_1Device.html#a6c2cfdf77b356eb8d0104c5ce0e78154',1,'DepthSense::Device']]],
  ['noderemovedevent',['nodeRemovedEvent',['../classDepthSense_1_1Device.html#a6bb0448a019b51239b9f643e3d1f4467',1,'DepthSense::Device']]]
];
