var searchData=
[
  ['model',['Model',['../classDepthSense_1_1Device.html#a30defbe125aca0d3e0d5ca060cb9a8af',1,'DepthSense::Device']]]
];
