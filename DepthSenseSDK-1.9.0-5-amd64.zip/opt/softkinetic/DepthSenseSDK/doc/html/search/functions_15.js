var searchData=
[
  ['whitebalanceautoisreadonly',['whiteBalanceAutoIsReadOnly',['../classDepthSense_1_1ColorNode.html#ab8e8d4da31007da7c8335c60a8181871',1,'DepthSense::ColorNode']]],
  ['whitebalanceisreadonly',['whiteBalanceIsReadOnly',['../classDepthSense_1_1ColorNode.html#a1815b37fbde6e01f5717def5aed93434',1,'DepthSense::ColorNode']]]
];
