var searchData=
[
  ['gain',['gain',['../classDepthSense_1_1ColorNode.html#a29caee7a6d318a7dd19f67e42468db75',1,'DepthSense::ColorNode']]],
  ['gamma',['gamma',['../classDepthSense_1_1ColorNode.html#a8ce0edb6106dc16ac0082a1b8c346725',1,'DepthSense::ColorNode']]]
];
