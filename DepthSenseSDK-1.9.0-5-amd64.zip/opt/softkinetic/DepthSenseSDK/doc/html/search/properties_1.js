var searchData=
[
  ['brightness',['brightness',['../classDepthSense_1_1ColorNode.html#ab7d5cc5370627296eac78b3bcb8bf264',1,'DepthSense::ColorNode']]],
  ['buttonid',['buttonID',['../classDepthSense_1_1Depth_1_1ButtonEventData.html#a123f4e231f6f0d145487b2a65d5d3ce9',1,'DepthSense::Depth::ButtonEventData']]]
];
