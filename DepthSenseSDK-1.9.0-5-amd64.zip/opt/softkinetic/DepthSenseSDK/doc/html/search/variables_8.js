var searchData=
[
  ['major',['major',['../structDepthSense_1_1Version.html#a593b54ac3f94cae3b4e55babb499558d',1,'DepthSense::Version']]],
  ['minor',['minor',['../structDepthSense_1_1Version.html#a81510082714647c47f5ccbbf19c97ae4',1,'DepthSense::Version']]],
  ['mode',['mode',['../structDepthSense_1_1Depth_1_1Configuration.html#a9267752e6999b9e6b43463f3c13977bd',1,'DepthSense::Depth::Configuration::mode()'],['../structDepthSense_1_1DepthNode_1_1Configuration.html#a16c435156788d6f85ac0be703aae1688',1,'DepthSense::DepthNode::Configuration::mode()']]]
];
