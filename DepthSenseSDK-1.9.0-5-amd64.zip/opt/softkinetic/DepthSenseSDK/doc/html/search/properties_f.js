var searchData=
[
  ['saturation',['saturation',['../classDepthSense_1_1ColorNode.html#a20fbd7ba69d4e4e7f289ea6e76f5ce43',1,'DepthSense::ColorNode']]],
  ['serialnumber',['serialNumber',['../classDepthSense_1_1Node.html#a120582b3b99a3f5162176399e7fd4cd0',1,'DepthSense::Node::serialNumber()'],['../classDepthSense_1_1Device.html#a1b589f582e8f1c272f0b00d66761ee01',1,'DepthSense::Device::serialNumber()']]],
  ['sharpness',['sharpness',['../classDepthSense_1_1ColorNode.html#a5d0d930fcb9c0e17128a60eb1895aa33',1,'DepthSense::ColorNode']]],
  ['stereocameraparameters',['stereoCameraParameters',['../classDepthSense_1_1Depth_1_1SampleData.html#ae1cd9261f777a931bfea6217c861d38d',1,'DepthSense::Depth::SampleData::stereoCameraParameters()'],['../classDepthSense_1_1Device.html#a16e0fe20c9b46418c55236d858fd53d5',1,'DepthSense::Device::stereoCameraParameters()']]]
];
