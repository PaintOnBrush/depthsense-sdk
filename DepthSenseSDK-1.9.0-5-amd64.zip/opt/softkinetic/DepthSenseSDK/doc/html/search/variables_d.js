var searchData=
[
  ['t1',['t1',['../structDepthSense_1_1ExtrinsicParameters.html#af60f7c4e16e35dee9a2f73f63fe53ad2',1,'DepthSense::ExtrinsicParameters']]],
  ['t2',['t2',['../structDepthSense_1_1ExtrinsicParameters.html#ad9a482fdf8f7f8da7b283fb14b528370',1,'DepthSense::ExtrinsicParameters']]],
  ['t3',['t3',['../structDepthSense_1_1ExtrinsicParameters.html#ac25805c826ddd2260e217a7a5f6520dd',1,'DepthSense::ExtrinsicParameters']]],
  ['timeofarrival',['timeOfArrival',['../structDepthSense_1_1AudioNode_1_1NewSampleReceivedData.html#a3425a535a9fd9afc13b029ab228477bb',1,'DepthSense::AudioNode::NewSampleReceivedData::timeOfArrival()'],['../structDepthSense_1_1ColorNode_1_1NewSampleReceivedData.html#a4ec671c2e1d4ba0aa13d4a5a2e0700ae',1,'DepthSense::ColorNode::NewSampleReceivedData::timeOfArrival()'],['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#a12cb262de62fed180892ce8ebf5e8903',1,'DepthSense::DepthNode::NewSampleReceivedData::timeOfArrival()']]],
  ['timeofcapture',['timeOfCapture',['../structDepthSense_1_1AudioNode_1_1NewSampleReceivedData.html#a161f35d6f76daf31f39244b2c0a6dd2a',1,'DepthSense::AudioNode::NewSampleReceivedData::timeOfCapture()'],['../structDepthSense_1_1ColorNode_1_1NewSampleReceivedData.html#a6b152f8d8447b01585d2adfa4a00a1ca',1,'DepthSense::ColorNode::NewSampleReceivedData::timeOfCapture()'],['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#ae131f53ae77e7566baa636ef25c12e1a',1,'DepthSense::DepthNode::NewSampleReceivedData::timeOfCapture()']]]
];
