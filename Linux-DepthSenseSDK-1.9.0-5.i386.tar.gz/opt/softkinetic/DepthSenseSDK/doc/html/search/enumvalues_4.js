var searchData=
[
  ['power_5fline_5ffrequency_5f50hz',['POWER_LINE_FREQUENCY_50HZ',['../namespaceDepthSense.html#a3568253bc054e4a9751739c62f515fceaa312ede3ae7453b6614c716961df7df9',1,'DepthSense']]],
  ['power_5fline_5ffrequency_5f60hz',['POWER_LINE_FREQUENCY_60HZ',['../namespaceDepthSense.html#a3568253bc054e4a9751739c62f515fceafdbe19a1aa7ccaef06c8e1daf1f6bbfd',1,'DepthSense']]],
  ['power_5fline_5ffrequency_5fdisabled',['POWER_LINE_FREQUENCY_DISABLED',['../namespaceDepthSense.html#a3568253bc054e4a9751739c62f515fceaea100f9755453a4aa1581f3fc9316cd6',1,'DepthSense']]]
];
