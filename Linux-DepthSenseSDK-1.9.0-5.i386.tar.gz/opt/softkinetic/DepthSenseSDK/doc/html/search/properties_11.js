var searchData=
[
  ['usbbackendversion',['usbBackendVersion',['../classDepthSense_1_1Device.html#a02ca7789779b692588598ae9c6e95ae3',1,'DepthSense::Device']]],
  ['uvmap',['uvMap',['../classDepthSense_1_1Depth_1_1SampleData.html#a2fbbb7326747e12c5da38eb00060c806',1,'DepthSense::Depth::SampleData']]]
];
