var searchData=
[
  ['registernode',['registerNode',['../classDepthSense_1_1Context.html#a907c33e91a33ab8e6ae986fa6d774611',1,'DepthSense::Context']]],
  ['releasecontrol',['releaseControl',['../classDepthSense_1_1Context.html#aa490af6913e84b8f47731a8a0aafef2e',1,'DepthSense::Context::releaseControl(DepthSense::Device device)'],['../classDepthSense_1_1Context.html#a2020046c02adf7701a3f01f53c9362a0',1,'DepthSense::Context::releaseControl(DepthSense::Node node)']]],
  ['requestcontrol',['requestControl',['../classDepthSense_1_1Context.html#a93eeb4e463e82ef374fade8dfb7f7936',1,'DepthSense::Context::requestControl(DepthSense::Device device)'],['../classDepthSense_1_1Context.html#acf5117094528d9d265d05caea448df21',1,'DepthSense::Context::requestControl(DepthSense::Device device, int32_t timeout)'],['../classDepthSense_1_1Context.html#a4f827bee7490e6d0779a46b958c1a98f',1,'DepthSense::Context::requestControl(DepthSense::Node node)'],['../classDepthSense_1_1Context.html#a6a8e3371012913c7efcc50c3c3481b18',1,'DepthSense::Context::requestControl(DepthSense::Node node, int32_t timeout)']]],
  ['run',['run',['../classDepthSense_1_1Context.html#a632dff4237ba581f663f78881a2d3f8d',1,'DepthSense::Context']]]
];
