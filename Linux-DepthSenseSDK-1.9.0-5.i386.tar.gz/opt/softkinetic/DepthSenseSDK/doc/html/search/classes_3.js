var searchData=
[
  ['decompression_5fhelper',['decompression_helper',['../classDepthSense_1_1decompression__helper.html',1,'DepthSense']]],
  ['depthnode',['DepthNode',['../classDepthSense_1_1DepthNode.html',1,'DepthSense']]],
  ['device',['Device',['../classDepthSense_1_1Device.html',1,'DepthSense']]],
  ['deviceaddeddata',['DeviceAddedData',['../structDepthSense_1_1Context_1_1DeviceAddedData.html',1,'DepthSense::Context']]],
  ['deviceaddedevent',['DeviceAddedEvent',['../classDepthSense_1_1Context_1_1DeviceAddedEvent.html',1,'DepthSense::Context']]],
  ['deviceremoveddata',['DeviceRemovedData',['../structDepthSense_1_1Context_1_1DeviceRemovedData.html',1,'DepthSense::Context']]],
  ['deviceremovedevent',['DeviceRemovedEvent',['../classDepthSense_1_1Context_1_1DeviceRemovedEvent.html',1,'DepthSense::Context']]]
];
