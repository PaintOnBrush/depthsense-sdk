var searchData=
[
  ['u',['u',['../structDepthSense_1_1UV.html#ac9b72b5f5c10aeaa18c289fcb28aca3d',1,'DepthSense::UV']]],
  ['uvmap',['uvMap',['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#ab0a9c3c50fd4fb656cb29893173c51b2',1,'DepthSense::DepthNode::NewSampleReceivedData']]]
];
