var searchData=
[
  ['overheated',['overheated',['../classDepthSense_1_1Device.html#a9ed826df3572b8c43dcab8ea0273053a',1,'DepthSense::Device']]],
  ['overheating',['overheating',['../classDepthSense_1_1Device.html#a1956bc6a907efa7c833ca38092e7f079',1,'DepthSense::Device']]]
];
