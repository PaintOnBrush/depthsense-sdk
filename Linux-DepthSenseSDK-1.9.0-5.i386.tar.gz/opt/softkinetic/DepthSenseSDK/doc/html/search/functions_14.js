var searchData=
[
  ['version',['Version',['../structDepthSense_1_1Version.html#a776342cee9cbd55dd9b6da6eea7917c1',1,'DepthSense::Version']]],
  ['vertex',['Vertex',['../structDepthSense_1_1Vertex.html#afa79adc7eb23d979d2ea69a53e921c87',1,'DepthSense::Vertex']]]
];
