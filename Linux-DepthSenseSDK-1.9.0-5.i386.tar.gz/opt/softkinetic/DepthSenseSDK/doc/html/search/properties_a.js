var searchData=
[
  ['mediainterface',['mediaInterface',['../classDepthSense_1_1Node.html#a1e1f464eb0705d775bc7edc800164119',1,'DepthSense::Node']]],
  ['model',['model',['../classDepthSense_1_1Device.html#aa050020a51332ea4a3a8fbfb357bfffd',1,'DepthSense::Device']]],
  ['mute',['mute',['../classDepthSense_1_1AudioNode.html#af2608e5ee5c4a1e53970b8758b74fafa',1,'DepthSense::AudioNode']]]
];
