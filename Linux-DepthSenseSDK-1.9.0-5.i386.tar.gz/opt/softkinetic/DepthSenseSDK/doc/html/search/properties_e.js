var searchData=
[
  ['range',['range',['../classDepthSense_1_1DepthNode.html#a5973bb4ec0a2ba6c5e8452ecf263ca9a',1,'DepthSense::DepthNode']]],
  ['reason',['reason',['../classDepthSense_1_1UnsupportedNode.html#a4dd51b4a7fe4675a81dcf1e397965f3e',1,'DepthSense::UnsupportedNode']]],
  ['registerednodes',['registeredNodes',['../classDepthSense_1_1Context.html#a10a9f313adb1ab0224abc854aaccc17a',1,'DepthSense::Context']]],
  ['revision',['revision',['../classDepthSense_1_1Node.html#a9df09ce03f0a1af21c60063985552b2d',1,'DepthSense::Node']]]
];
