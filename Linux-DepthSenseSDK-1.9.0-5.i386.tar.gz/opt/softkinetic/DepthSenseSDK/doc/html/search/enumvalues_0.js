var searchData=
[
  ['camera_5fplane_5fcolor',['CAMERA_PLANE_COLOR',['../namespaceDepthSense.html#a57c659d5e702016bb71c489d83c40a6ca25fa47a99f5fd9dc865d6a0778380433',1,'DepthSense']]],
  ['camera_5fplane_5fdepth',['CAMERA_PLANE_DEPTH',['../namespaceDepthSense.html#a57c659d5e702016bb71c489d83c40a6caa45e2ef30a6c462916eb29a3ea7e35cb',1,'DepthSense']]],
  ['capabilities_5faccelerometer',['CAPABILITIES_ACCELEROMETER',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1ad26435f008b81d05bc111ef46d5ee94d',1,'DepthSense::Device']]],
  ['capabilities_5faudio',['CAPABILITIES_AUDIO',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1a34b68369694cc92f85e70e6ff56c31ee',1,'DepthSense::Device']]],
  ['capabilities_5fcolor',['CAPABILITIES_COLOR',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1a9e540adec831898beace9ae2e1b205e1',1,'DepthSense::Device']]],
  ['capabilities_5fdepth',['CAPABILITIES_DEPTH',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1adb54e01eff10ffd904567846bfcc7645',1,'DepthSense::Device']]],
  ['capabilities_5fimu',['CAPABILITIES_IMU',['../classDepthSense_1_1Device.html#ab9cdb6aaaa72eb7d8fd1674375fbe9e1a8948eca743d3d9b81ea38e17692c51f4',1,'DepthSense::Device']]],
  ['compression_5ftype_5fmjpeg',['COMPRESSION_TYPE_MJPEG',['../namespaceDepthSense.html#ac0e14943b53ce044cb535f2b94562391acdd5bc3012f9ac926fd2d98fc761e3ff',1,'DepthSense']]],
  ['compression_5ftype_5fyuy2',['COMPRESSION_TYPE_YUY2',['../namespaceDepthSense.html#ac0e14943b53ce044cb535f2b94562391ae96831f2e0283a12f43b4184788fa078',1,'DepthSense']]],
  ['coordinate_5fsystem_5ftype_5fleft_5fhanded',['COORDINATE_SYSTEM_TYPE_LEFT_HANDED',['../namespaceDepthSense.html#af03d4223413374093437dd4d2712181ba9a0dcf87ece2090662febb4f26546e0e',1,'DepthSense']]],
  ['coordinate_5fsystem_5ftype_5fright_5fhanded',['COORDINATE_SYSTEM_TYPE_RIGHT_HANDED',['../namespaceDepthSense.html#af03d4223413374093437dd4d2712181ba90fc7d8d29c974497580e48a647c9811',1,'DepthSense']]]
];
