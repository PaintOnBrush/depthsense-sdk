var searchData=
[
  ['depth',['depth',['../structDepthSense_1_1Extended2DPoint.html#ab4d8b498cffb1ad61b04504582c2bc44',1,'DepthSense::Extended2DPoint::depth()'],['../structDepthSense_1_1FPExtended2DPoint.html#a40d9089563127f53feb92f71c80c919b',1,'DepthSense::FPExtended2DPoint::depth()']]],
  ['depthintrinsics',['depthIntrinsics',['../structDepthSense_1_1StereoCameraParameters.html#ad6d5d79ff67126ffa3e2f9ffb8c14bee',1,'DepthSense::StereoCameraParameters']]],
  ['depthmap',['depthMap',['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#a4a62b8f63ac3140be5f31efd9b0d7e99',1,'DepthSense::DepthNode::NewSampleReceivedData']]],
  ['depthmapfloatingpoint',['depthMapFloatingPoint',['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#a205adaa6fea3c79e32ed4ce5453f5ebd',1,'DepthSense::DepthNode::NewSampleReceivedData']]],
  ['device',['device',['../structDepthSense_1_1Context_1_1DeviceAddedData.html#a3b563765f8ab3985f760724c54f4f21d',1,'DepthSense::Context::DeviceAddedData::device()'],['../structDepthSense_1_1Context_1_1DeviceRemovedData.html#a240ce6e2f91725b5a00f7999411791ff',1,'DepthSense::Context::DeviceRemovedData::device()']]],
  ['droppedsamplecount',['droppedSampleCount',['../structDepthSense_1_1AudioNode_1_1NewSampleReceivedData.html#af2c011393771823a3914c0d9512b2c78',1,'DepthSense::AudioNode::NewSampleReceivedData::droppedSampleCount()'],['../structDepthSense_1_1ColorNode_1_1NewSampleReceivedData.html#a68bad4b88fb196770897ddf92387d054',1,'DepthSense::ColorNode::NewSampleReceivedData::droppedSampleCount()'],['../structDepthSense_1_1DepthNode_1_1NewSampleReceivedData.html#a402bea0c9ab22bd4e690ce64411c601c',1,'DepthSense::DepthNode::NewSampleReceivedData::droppedSampleCount()']]]
];
