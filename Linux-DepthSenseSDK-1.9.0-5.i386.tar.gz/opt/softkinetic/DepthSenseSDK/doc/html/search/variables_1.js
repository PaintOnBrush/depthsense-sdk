var searchData=
[
  ['bitspersample',['bitsPerSample',['../structDepthSense_1_1Audio_1_1Configuration.html#a1a81955105547c13ec96b57fd8075a28',1,'DepthSense::Audio::Configuration::bitsPerSample()'],['../structDepthSense_1_1AudioNode_1_1Configuration.html#a273c78fd12ad3b29338474e3facee5a9',1,'DepthSense::AudioNode::Configuration::bitsPerSample()']]],
  ['build',['build',['../structDepthSense_1_1Version.html#a7f1fe71975e0989aea9ce92b8e3e8006',1,'DepthSense::Version']]]
];
