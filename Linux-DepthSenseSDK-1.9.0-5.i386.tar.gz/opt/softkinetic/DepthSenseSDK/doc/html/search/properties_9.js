var searchData=
[
  ['lasterror',['lastError',['../classDepthSense_1_1Depth_1_1IMUData.html#ab93092177b14047882c1ea1b5dc78d37',1,'DepthSense::Depth::IMUData']]]
];
