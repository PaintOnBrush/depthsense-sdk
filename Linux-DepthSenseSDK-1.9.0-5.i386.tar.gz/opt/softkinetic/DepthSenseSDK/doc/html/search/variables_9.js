var searchData=
[
  ['node',['node',['../structDepthSense_1_1Device_1_1NodeAddedData.html#a07059602a7ef496baf0720658307d77f',1,'DepthSense::Device::NodeAddedData::node()'],['../structDepthSense_1_1Device_1_1NodeRemovedData.html#a0438188760eb54bebab8e92a784d6be2',1,'DepthSense::Device::NodeRemovedData::node()']]]
];
